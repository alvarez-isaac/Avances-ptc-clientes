﻿namespace Presentacion
{
    partial class InterfazAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pcontainer = new System.Windows.Forms.Panel();
            this.PanelForms = new System.Windows.Forms.Panel();
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.pnlClientes = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pnlVehiculos = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pnlEmpleados = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pnlInventario = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.btnHome = new System.Windows.Forms.PictureBox();
            this.btnMenu = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pnlBotonesInterfaz = new System.Windows.Forms.Panel();
            this.btnMinimizar = new System.Windows.Forms.PictureBox();
            this.btnCerrar = new System.Windows.Forms.PictureBox();
            this.btnMaximize = new System.Windows.Forms.PictureBox();
            this.pbLogo = new System.Windows.Forms.PictureBox();
            this.Pcontainer.SuspendLayout();
            this.pnlMenu.SuspendLayout();
            this.pnlClientes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.pnlVehiculos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.pnlEmpleados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.pnlInventario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMenu)).BeginInit();
            this.panel1.SuspendLayout();
            this.pnlBotonesInterfaz.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMaximize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // Pcontainer
            // 
            this.Pcontainer.BackColor = System.Drawing.Color.Transparent;
            this.Pcontainer.Controls.Add(this.PanelForms);
            this.Pcontainer.Controls.Add(this.pnlMenu);
            this.Pcontainer.Controls.Add(this.panel1);
            this.Pcontainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.Pcontainer.Location = new System.Drawing.Point(0, 0);
            this.Pcontainer.Name = "Pcontainer";
            this.Pcontainer.Size = new System.Drawing.Size(1347, 660);
            this.Pcontainer.TabIndex = 4;
            this.Pcontainer.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pcontainer_MouseDown);
            // 
            // PanelForms
            // 
            this.PanelForms.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelForms.Location = new System.Drawing.Point(261, 55);
            this.PanelForms.Name = "PanelForms";
            this.PanelForms.Size = new System.Drawing.Size(1086, 605);
            this.PanelForms.TabIndex = 51;
            // 
            // pnlMenu
            // 
            this.pnlMenu.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.pnlMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.pnlMenu.Controls.Add(this.pnlClientes);
            this.pnlMenu.Controls.Add(this.pnlVehiculos);
            this.pnlMenu.Controls.Add(this.pnlEmpleados);
            this.pnlMenu.Controls.Add(this.pnlInventario);
            this.pnlMenu.Controls.Add(this.panel2);
            this.pnlMenu.Controls.Add(this.btnMenu);
            this.pnlMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.pnlMenu.Location = new System.Drawing.Point(0, 55);
            this.pnlMenu.Margin = new System.Windows.Forms.Padding(0);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(261, 605);
            this.pnlMenu.TabIndex = 50;
            // 
            // pnlClientes
            // 
            this.pnlClientes.Controls.Add(this.label2);
            this.pnlClientes.Controls.Add(this.pictureBox4);
            this.pnlClientes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlClientes.Location = new System.Drawing.Point(7, 179);
            this.pnlClientes.Name = "pnlClientes";
            this.pnlClientes.Size = new System.Drawing.Size(246, 63);
            this.pnlClientes.TabIndex = 0;
            this.pnlClientes.Click += new System.EventHandler(this.pnlClientes_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label2.Font = new System.Drawing.Font("Microsoft New Tai Lue", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(87, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 30);
            this.label2.TabIndex = 45;
            this.label2.Text = "Clientes";
            this.label2.Click += new System.EventHandler(this.pnlClientes_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = global::Vistas.Properties.Resources.People;
            this.pictureBox4.Location = new System.Drawing.Point(6, 3);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(50, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 41;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pnlClientes_Click);
            // 
            // pnlVehiculos
            // 
            this.pnlVehiculos.Controls.Add(this.label3);
            this.pnlVehiculos.Controls.Add(this.pictureBox5);
            this.pnlVehiculos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlVehiculos.Location = new System.Drawing.Point(7, 248);
            this.pnlVehiculos.Name = "pnlVehiculos";
            this.pnlVehiculos.Size = new System.Drawing.Size(246, 63);
            this.pnlVehiculos.TabIndex = 1;
            this.pnlVehiculos.Click += new System.EventHandler(this.pnlVehiculos_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label3.Font = new System.Drawing.Font("Microsoft New Tai Lue", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(87, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 30);
            this.label3.TabIndex = 46;
            this.label3.Text = "Vehículos";
            this.label3.Click += new System.EventHandler(this.pnlVehiculos_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox5.Image = global::Vistas.Properties.Resources.Directions_car;
            this.pictureBox5.Location = new System.Drawing.Point(5, 10);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(50, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 42;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pnlVehiculos_Click);
            // 
            // pnlEmpleados
            // 
            this.pnlEmpleados.Controls.Add(this.label5);
            this.pnlEmpleados.Controls.Add(this.pictureBox7);
            this.pnlEmpleados.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlEmpleados.Location = new System.Drawing.Point(7, 386);
            this.pnlEmpleados.Name = "pnlEmpleados";
            this.pnlEmpleados.Size = new System.Drawing.Size(246, 63);
            this.pnlEmpleados.TabIndex = 2;
            this.pnlEmpleados.Click += new System.EventHandler(this.pnlEmpleados_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label5.Font = new System.Drawing.Font("Microsoft New Tai Lue", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(87, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(129, 30);
            this.label5.TabIndex = 48;
            this.label5.Text = "Empleados";
            this.label5.Click += new System.EventHandler(this.pnlEmpleados_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox7.Image = global::Vistas.Properties.Resources.Vector;
            this.pictureBox7.Location = new System.Drawing.Point(6, 13);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(50, 40);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 44;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pnlEmpleados_Click);
            // 
            // pnlInventario
            // 
            this.pnlInventario.Controls.Add(this.pictureBox6);
            this.pnlInventario.Controls.Add(this.label4);
            this.pnlInventario.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pnlInventario.Location = new System.Drawing.Point(7, 317);
            this.pnlInventario.Name = "pnlInventario";
            this.pnlInventario.Size = new System.Drawing.Size(246, 63);
            this.pnlInventario.TabIndex = 2;
            this.pnlInventario.Click += new System.EventHandler(this.pnlInventario_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox6.Image = global::Vistas.Properties.Resources.engine_motor_icon_1;
            this.pictureBox6.Location = new System.Drawing.Point(5, 3);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(50, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 43;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Click += new System.EventHandler(this.pnlInventario_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft New Tai Lue", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(87, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 30);
            this.label4.TabIndex = 47;
            this.label4.Text = "Inventario";
            this.label4.Click += new System.EventHandler(this.pnlInventario_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.btnHome);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel2.Location = new System.Drawing.Point(7, 113);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(246, 63);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Microsoft New Tai Lue", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(87, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 30);
            this.label1.TabIndex = 39;
            this.label1.Text = "Inicio";
            // 
            // btnHome
            // 
            this.btnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHome.Image = global::Vistas.Properties.Resources.Home;
            this.btnHome.Location = new System.Drawing.Point(6, 3);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(50, 50);
            this.btnHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnHome.TabIndex = 40;
            this.btnHome.TabStop = false;
            // 
            // btnMenu
            // 
            this.btnMenu.Image = global::Vistas.Properties.Resources.icons8_menú_50;
            this.btnMenu.Location = new System.Drawing.Point(13, 18);
            this.btnMenu.Name = "btnMenu";
            this.btnMenu.Size = new System.Drawing.Size(49, 50);
            this.btnMenu.TabIndex = 49;
            this.btnMenu.TabStop = false;
            this.btnMenu.Click += new System.EventHandler(this.btnMenu_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(217)))), ((int)(((byte)(7)))), ((int)(((byte)(45)))));
            this.panel1.Controls.Add(this.pnlBotonesInterfaz);
            this.panel1.Controls.Add(this.pbLogo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1347, 55);
            this.panel1.TabIndex = 26;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Pcontainer_MouseDown);
            // 
            // pnlBotonesInterfaz
            // 
            this.pnlBotonesInterfaz.Controls.Add(this.btnMinimizar);
            this.pnlBotonesInterfaz.Controls.Add(this.btnCerrar);
            this.pnlBotonesInterfaz.Controls.Add(this.btnMaximize);
            this.pnlBotonesInterfaz.Dock = System.Windows.Forms.DockStyle.Right;
            this.pnlBotonesInterfaz.Location = new System.Drawing.Point(1145, 0);
            this.pnlBotonesInterfaz.Name = "pnlBotonesInterfaz";
            this.pnlBotonesInterfaz.Size = new System.Drawing.Size(202, 55);
            this.pnlBotonesInterfaz.TabIndex = 28;
            // 
            // btnMinimizar
            // 
            this.btnMinimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMinimizar.Image = global::Vistas.Properties.Resources.icons8_signo_menos_321;
            this.btnMinimizar.Location = new System.Drawing.Point(66, 3);
            this.btnMinimizar.Name = "btnMinimizar";
            this.btnMinimizar.Size = new System.Drawing.Size(33, 38);
            this.btnMinimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnMinimizar.TabIndex = 6;
            this.btnMinimizar.TabStop = false;
            this.btnMinimizar.Click += new System.EventHandler(this.btnMinimizar_Click);
            // 
            // btnCerrar
            // 
            this.btnCerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCerrar.Image = global::Vistas.Properties.Resources.icons8_x_50;
            this.btnCerrar.Location = new System.Drawing.Point(154, 3);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(0);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(42, 42);
            this.btnCerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnCerrar.TabIndex = 5;
            this.btnCerrar.TabStop = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // btnMaximize
            // 
            this.btnMaximize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMaximize.Image = global::Vistas.Properties.Resources.icons8_pantalla_completa_50;
            this.btnMaximize.Location = new System.Drawing.Point(105, 2);
            this.btnMaximize.Name = "btnMaximize";
            this.btnMaximize.Size = new System.Drawing.Size(46, 42);
            this.btnMaximize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnMaximize.TabIndex = 7;
            this.btnMaximize.TabStop = false;
            this.btnMaximize.Click += new System.EventHandler(this.btnMaximize_Click);
            // 
            // pbLogo
            // 
            this.pbLogo.Dock = System.Windows.Forms.DockStyle.Left;
            this.pbLogo.Image = global::Vistas.Properties.Resources.Logo;
            this.pbLogo.Location = new System.Drawing.Point(0, 0);
            this.pbLogo.Name = "pbLogo";
            this.pbLogo.Size = new System.Drawing.Size(338, 55);
            this.pbLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLogo.TabIndex = 28;
            this.pbLogo.TabStop = false;
            // 
            // InterfazAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1347, 660);
            this.Controls.Add(this.Pcontainer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(650, 300);
            this.Name = "InterfazAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InterfazAdmin";
            this.Load += new System.EventHandler(this.InterfazAdmin_Load);
            this.Pcontainer.ResumeLayout(false);
            this.pnlMenu.ResumeLayout(false);
            this.pnlClientes.ResumeLayout(false);
            this.pnlClientes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.pnlVehiculos.ResumeLayout(false);
            this.pnlVehiculos.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.pnlEmpleados.ResumeLayout(false);
            this.pnlEmpleados.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.pnlInventario.ResumeLayout(false);
            this.pnlInventario.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnHome)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMenu)).EndInit();
            this.panel1.ResumeLayout(false);
            this.pnlBotonesInterfaz.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnCerrar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMaximize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLogo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel Pcontainer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pbLogo;
        private System.Windows.Forms.PictureBox btnMinimizar;
        private System.Windows.Forms.PictureBox btnCerrar;
        private System.Windows.Forms.PictureBox btnMaximize;
        private System.Windows.Forms.Panel pnlBotonesInterfaz;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox btnHome;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Panel PanelForms;
        private System.Windows.Forms.PictureBox btnMenu;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel pnlEmpleados;
        private System.Windows.Forms.Panel pnlInventario;
        private System.Windows.Forms.Panel pnlVehiculos;
        private System.Windows.Forms.Panel pnlClientes;
    }
}