﻿using Modelos.Conexion;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vistas.Forms.FormsMenu
{
    public partial class Clientes : Form
    {
        public Clientes()
        {
            InitializeComponent();
        }

        private void Clientes_Load(object sender, EventArgs e)
        {
            ConexionClientes.Conectar();
            dgvlistadoClientes.DataSource = Index();
        }

        public DataTable Index()
        {
            ConexionClientes.Conectar();

            DataTable DatosVirtual = new DataTable();
            string sql = "SELECT * FROM Cliente";
            SqlCommand comando = new SqlCommand(sql, ConexionClientes.Conectar());

            SqlDataAdapter adapter = new SqlDataAdapter(comando);

            adapter.Fill(DatosVirtual);

            return DatosVirtual;
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            ConexionClientes.Conectar();

            string SqlInsert = "INSERT INTO Cliente (nombre,dui,telefono,correo,fechaIngreso) VALUES (@Nombre, @dui, @telefono, @correo, @fechaIngreso)";
            SqlCommand comando1 = new SqlCommand(SqlInsert, ConexionClientes.Conectar());

            comando1.Parameters.AddWithValue("@Nombre", txtNombre.Text);
            comando1.Parameters.AddWithValue("@dui", txtDui.Text);
            comando1.Parameters.AddWithValue("@telefono", txtTelefono.Text);
            comando1.Parameters.AddWithValue("@correo", txtCorreo.Text);
            comando1.Parameters.AddWithValue("@fechaIngreso", txtFechaIngreso. Text);

            comando1.ExecuteNonQuery();

            MessageBox.Show("Cliente agregado correctamente");
            dgvlistadoClientes.DataSource = Index();
        }
    }
}
