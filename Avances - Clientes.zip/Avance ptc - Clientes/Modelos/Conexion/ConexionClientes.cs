﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modelos.Conexion
{
    //Como conectar a la base de datos de clientes (CAMBIAR SOLO NOMBRE DEL SERVIDOR Y BASE DE DATOS) -isaac
    public class ConexionClientes
    {
        public static SqlConnection Conectar()
        {
            SqlConnection conexion = new SqlConnection("Server=LAPTOP-KN78UST4\\SQLEXPRESS;DataBase=SistemaDeAdministracionTallerAutomotrizDB; integrated security=true");
            conexion.Open();

            return conexion;
        }
    }
}
